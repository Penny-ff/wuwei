% 定义电机参数
P_rated = [3000, 1400]; % 额定功率 (W)
N_rated = [8000, 9000]; % 额定转速 (RPM)
V_rated = [22, 22]; % 额定电压 (V)
I_rated = [140, 70]; % 额定电流 (A)
efficiency = [0.8, 0.8]; % 转动效率
J = [1.83e-3, 0.94e-3]; % 电机转动惯量 (kgfm^2)

% 初始化角度和时间
theta = [0, 0]; % 角度 (弧度)
t = 0; % 时间 (秒)
dt = 0.001; % 时间步长 (秒)

% 定义目标角度速度和PID控制器参数
theta_target_rate = [30 * pi / 180, 20 * pi / 180]; % 目标角度速度 (弧度/秒)
Kp = [10, 10]; % 比例增益
Ki = [3.3, 4.2]; % 积分增益
Kd = [0.05, 0.01]; % 微分增益
error_sum = [0, 0]; % 积分误差
error_prev = [0, 0]; % 上一步的误差

% 初始化角度记录和时间记录
theta_record = [[0; 0]]; % 角度记录 (弧度)
theta_target_record = [[0; 0]]; % 目标角度记录 (弧度)
t_record = [0]; % 时间记录 (秒)

% 模拟电机运行1秒
while t < 1
    for i = 1:2
        % 更新目标角度
        theta_target(i) = theta_target_rate(i) * t;
        % 计算误差
        error = theta_target(i) - theta(i);
        % 计算PID控制器的输出
        u = Kp(i) * error + Ki(i) * error_sum(i) + Kd(i) * (error - error_prev(i));
        % 更新积分误差和上一步的误差
        error_sum(i) = error_sum(i) + error;
        error_prev(i) = error;
        % 计算扭矩
        T = P_rated(i) / (N_rated(i) * 2 * pi / 60) + u;
        % 计算角加速度
        alpha = T / J(i);
        % 计算角速度
        omega = alpha * dt;
        % 计算角度
        theta(i) = theta(i) + omega * dt;
        % 记录当前时间和角度
        theta_record = [theta_record, rad2deg(theta)'];
        theta_target_record = [theta_target_record, rad2deg(theta_target)'];
        t_record = [t_record, t];
    end
    t = t + dt;
end

% 将角度限制在0到360度之间
theta_record = mod(theta_record, 360);
theta_target_record = mod(theta_target_record, 360);
theta_target_record(2,2) = 0;%避免奇怪的错误

% 绘制角度随时间的变化图
figure(1);
plot(t_record, theta_record(1, :), 'r', 'LineWidth', 1.5);
hold on;
plot(t_record, theta_target_record(1, :), 'b--', 'LineWidth', 1.5);
hold off
xlabel('时间 (秒)');
ylabel('角度 (度)');
legend('炮塔实际方向位输出', '炮塔目标方向位');
title('角度随时间的变化');
figure(2)
plot(t_record, theta_record(2, :), 'r', 'LineWidth', 1.5);
hold on
plot(t_record, theta_target_record(2, :), 'b--', 'LineWidth', 1.5);
xlabel('时间 (秒)');
ylabel('角度 (度)');
legend('炮塔实际高低位输出', '炮塔目标高低位');
title('角度随时间的变化');
fprintf('方向位以最大速度的1/3等速运动时速跟踪精度: %.4f 度\n',abs(mean(theta_target_record(1,:))-mean(theta_record(1,:))));
fprintf('高低位以最大速度的1/3等速运动时速跟踪精度: %.4f 度\n', abs(mean(theta_target_record(2,:))-mean(theta_record(2,:))));
